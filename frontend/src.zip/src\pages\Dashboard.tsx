export default function Dashboard() {
  return <div className="p-8 text-white/92">Dashboard</div>;
}